async function btn_click(){
    result = await eel.say_something('Hello word')()
    document.querySelector('p').innerHTML = result
}

async function btn_EXE(){
    document.querySelector('p').innerHTML = ar
}

// 跟python expose給JS 很像，不過是要在()內加上 function 名稱
eel.expose(js_bigger)
function js_bigger(count){
    //改變<p>tag 文字的大小     
    document.querySelector('p').style.fontSize = count
}

eel.expose(js_EXE)
function js_EXE(ar){
    return ar
}

// /* import the ipfs-http-client library */
// import { create } from 'ipfs-http-client';

// /* 创建一个 IPFS 客户端实例 */
// const client = ipfsHttpClient('https://ipfs.infura.io:5001/api/v0')

// /* 上传文件 */
// const added = await client.add(file)

// /* 上传字符串 */
// const added = await client.add('hello world')